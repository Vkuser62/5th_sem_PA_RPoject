package com.example.gkquiz.AdapterClass;

public class SubAdapter {
}
