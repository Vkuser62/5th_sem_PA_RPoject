package com.example.gkquiz;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.gkquiz.databinding.FragmentQuizBinding; // Ensure correct binding import
import com.example.gkquiz.modelClass.QuizModel;

import java.util.ArrayList;
import java.util.Objects;

public class QuizFragment extends Fragment {
    private FragmentQuizBinding binding; // Make this private to follow best practices
    private final ArrayList<QuizModel> list = new ArrayList<>();
    private int position = 0;
    int right = 0;
    private static String answer = null;
    int allQuestion;
    String listSize;
    private String positionNo;
    QuizModel  quizModel;


    public QuizFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout using binding
        binding = FragmentQuizBinding.inflate(inflater, container, false);

        loadQuestions();
        EnableOption();
        ClearOption();
        binding.nextBtn.setOnClickListener(v->{
        position++;
        loadQuestions();
        EnableOption();
        ClearOption();
        });
        return binding.getRoot();
    }

    private void ClearOption() {
        binding.option1Con.setBackgroundResource(R.drawable.sub_item_bg);
        binding.option2Con.setBackgroundResource(R.drawable.sub_item_bg);
        binding.option3Con.setBackgroundResource(R.drawable.sub_item_bg);
        binding.option4Con.setBackgroundResource(R.drawable.sub_item_bg);
        binding.nextBtn.setBackgroundResource(R.drawable.disable_btn);

    }

    private void EnableOption() {
        binding.option1Con.setEnabled(true);
        binding.option2Con.setEnabled(true);
        binding.option3Con.setEnabled(true);
        binding.option4Con.setEnabled(true);
        binding.nextBtn.setEnabled(false);

    }

    private void loadQuestions() {
        // Add questions to the list
        list.add(new QuizModel("What is the capital of France?", "Paris", "Berlin", "Rome", "Madrid", "Paris"));
        list.add(new QuizModel("Who discovered gravity?", "Newton", "Einstein", "Galileo", "Tesla", "Newton"));
        list.add(new QuizModel("What is the largest planet in our solar system?", "Mars", "Earth", "Jupiter", "Venus", "Jupiter"));
        list.add(new QuizModel("What is the boiling point of water?", "90°C", "100°C", "120°C", "80°C", "100°C"));
        list.add(new QuizModel("Which is the smallest prime number?", "1", "2", "3", "5", "2"));
        allQuestion = 5;
        listSize = String.valueOf(allQuestion);
        binding.totalQ.setText("/"+listSize);

        if(position != allQuestion){
            positionNo = String.valueOf(position + 1);
        }
        else{
            positionNo = String.valueOf(position);
        }

        quizModel = list.get(position);
        answer = quizModel.getCorrectAns();

        binding.questionCon.setText(quizModel.getQuestion());
        binding.option1Con.setText(quizModel.getOp1());
        binding.option2Con.setText(quizModel.getOp2());
        binding.option3Con.setText(quizModel.getOp3());
        binding.option4Con.setText(quizModel.getOp4());

        optionCheckUp();

    }

    private void optionCheckUp() {

      binding.option1Con.setOnClickListener(v->{
          if(Objects.equals(quizModel.getOp1(),quizModel.getCorrectAns())){
              right++;
              binding.option1Con.setBackgroundResource(R.drawable.right_bg);
          }
          else{
              ShowRightAns();
              binding.option1Con.setBackgroundResource(R.drawable.wrong_bg);
          }

          DisableOption();

      });
        binding.option2Con.setOnClickListener(v->{
            if(Objects.equals(quizModel.getOp2(),quizModel.getCorrectAns())){
                right++;
                binding.option2Con.setBackgroundResource(R.drawable.right_bg);
            }
            else{
                ShowRightAns();
                binding.option2Con.setBackgroundResource(R.drawable.wrong_bg);
            }
            DisableOption();
        });
        binding.option3Con.setOnClickListener(v->{
            if(Objects.equals(quizModel.getOp3(),quizModel.getCorrectAns())){
                right++;
                binding.option3Con.setBackgroundResource(R.drawable.right_bg);
            }
            else{
                ShowRightAns();
                binding.option3Con.setBackgroundResource(R.drawable.wrong_bg);
            }

            DisableOption();
        });
        binding.option4Con.setOnClickListener(v->{
            if(Objects.equals(quizModel.getOp4(),quizModel.getCorrectAns())){
                right++;
                binding.option4Con.setBackgroundResource(R.drawable.right_bg);
            }
            else{
                ShowRightAns();
                binding.option4Con.setBackgroundResource(R.drawable.wrong_bg);
            }
            DisableOption();
        });
    }

    private void DisableOption() {
        binding.option1Con.setEnabled(false);
        binding.option2Con.setEnabled(false);
        binding.option3Con.setEnabled(false);
        binding.option4Con.setEnabled(false);
        binding.nextBtn.setEnabled(true);
    }

    private void ShowRightAns() {
        if(Objects.equals(quizModel.getOp1(),quizModel.getCorrectAns())){
            binding.option1Con.setBackgroundResource(R.drawable.right_bg);
        }
        else if(Objects.equals(quizModel.getOp2(),quizModel.getCorrectAns())){
            binding.option2Con.setBackgroundResource(R.drawable.right_bg);
        }
        else if(Objects.equals(quizModel.getOp3(),quizModel.getCorrectAns())){
            binding.option3Con.setBackgroundResource(R.drawable.right_bg);
        }
        else if(Objects.equals(quizModel.getOp4(),quizModel.getCorrectAns())){
            binding.option4Con.setBackgroundResource(R.drawable.right_bg);
        }


    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        // Prevent memory leaks
        binding = null;
    }
}
