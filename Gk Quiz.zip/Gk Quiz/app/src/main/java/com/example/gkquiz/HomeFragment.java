package com.example.gkquiz;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.gkquiz.AdapterClass.HomeAdapter;
import com.example.gkquiz.databinding.FragmentHomeBinding;
import com.example.gkquiz.modelClass.HomeModel;

import java.util.ArrayList;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;
    private ArrayList<HomeModel> list = new ArrayList<>();
    private HomeAdapter adapter;

    public HomeFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout using ViewBinding
        binding = FragmentHomeBinding.inflate(inflater, container, false);

        // Initialize RecyclerView and load data
        LoadData();
        return binding.getRoot();
    }

    private void LoadData() {
        // Set up RecyclerView with a LinearLayoutManager
        binding.rcv.setLayoutManager(new LinearLayoutManager(getContext()));

        // Populate the data list
        list.clear();
        list.add(new HomeModel("Category 1", "Description 1"));
        list.add(new HomeModel("Category 2", "Description 2"));
        list.add(new HomeModel("Category 3", "Description 3"));
        list.add(new HomeModel("Category 4", "Description 4"));
        list.add(new HomeModel("Category 5", "Description 5"));

        // Set up the adapter
        adapter = new HomeAdapter(getContext(), list);
        binding.rcv.setAdapter(adapter);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null; // Avoid memory leaks
    }
}
