package com.example.quizapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.airbnb.lottie.LottieAnimationView;

public class ResultActivity extends AppCompatActivity {
    private LottieAnimationView animationView;
    private TextView scoreText, messageText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_result);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        animationView = findViewById(R.id.animationView);
        scoreText = findViewById(R.id.scoreText);
        messageText = findViewById(R.id.messageText);
        int score = getIntent().getIntExtra("SCORE", 0);
        int totalQuestions = getIntent().getIntExtra("TOTAL_QUESTIONS", 0);

        TextView scoreText = findViewById(R.id.scoreText);
        TextView messageText = findViewById(R.id.messageText);
       if(score<=totalQuestions/2){
           animationView.setAnimation(R.raw.try_again);
       }
        scoreText.setText(String.format("Score: %d/%d", score, totalQuestions));
        messageText.setText(getScoreMessage(score, totalQuestions));
    }
    private String getScoreMessage(int score, int totalQuestions) {
        float percentage = (score * 100f) / totalQuestions;
        if (percentage == 100) return "Perfect! You're a genius! 🎓";
        if (percentage >= 80) return "Great job! Almost perfect! 🌟";
        if (percentage >= 60) return "Good effort! Keep practicing! 💪";
        return "Don't give up! Try again! 🎯";
    }

    public void onTryAgainClick(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();
    }
}