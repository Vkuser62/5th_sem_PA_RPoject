package com.example.quizapp.utils;

import com.example.quizapp.R;
import com.example.quizapp.models.Category;
import com.example.quizapp.models.Question;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;

public class QuizData {
    public static List<Category> getCategories() {
        List<Category> categories = new ArrayList<>();
        categories.add(new Category(1, "java", R.drawable.ic_java, "#199ae8"));
        categories.add(new Category(2, "C program", R.drawable.ic_c, "#e8b90b"));
        categories.add(new Category(3, "HTML", R.drawable.ic_html, "#f37913"));
        categories.add(new Category(4, "DSA", R.drawable.ic_dsa, "#e11055"));
        categories.add(new Category(5, "React", R.drawable.ic_react, "#24d7ec"));
        categories.add(new Category(6, "Node", R.drawable.ic_node, "#07cf50"));
        categories.add(new Category(7, "csharp", R.drawable.ic_csharp, "#b510a1"));
        categories.add(new Category(8, "SQL", R.drawable.ic_sql, "#ded225"));
        return categories;
    }

    public static List<Question> getQuestionsForCategory(int categoryId) {
        List<Question> questions = new ArrayList<>();

        switch (categoryId) {
            case 1: // java
                questions.add(new Question(
                        "Which of the following option leads to the portability and security of Java?",
                        Arrays.asList("Bytecode is executed by JVM","The applet makes the Java code secure and portable",
                                "Use of exception handling","Dynamic binding between objects"),
                        0
                ));
                questions.add(new Question(
                        "Which of the following is not a Java features?",
                        Arrays.asList("Dynamic","Architecture Neutral","Use of pointers","Object-oriented"),
                        2
                ));
                questions.add(new Question(
                        " Which of the following is a valid keyword in Java?",
                        Arrays.asList("interface", "inherit", "unsigned", "friend"),
                        0
                ));
                questions.add(new Question(
                        "What is the size of the int data type in Java?",
                        Arrays.asList("4 bits", "8 bits", "16 bits", "32 bits"),
                        3
                ));
                questions.add(new Question(
                        "Which of the following is used to terminate a loop in Java?",
                        Arrays.asList("break", "continue", "return", "exit"),
                        0
                ));
                break;

            case 2: // C programming
                questions.add(new Question(
                        "Which of the following is used to declare a constant in C?",
                        Arrays.asList("const", "#define", "static", "volatile"),
                        1
                ));
                questions.add(new Question(
                        "What is the output of the following code?\n\nint a = 5;\nint b = 2;\nprintf(\"%d\", a % b);",
                        Arrays.asList("2", "1", "0", "Compiler Error"),
                        1
                ));
                questions.add(new Question(
                        "Which of the following is not a valid variable name in C?",
                        Arrays.asList("int_var", "_temp", "2nd_var", "value"),
                        2
                ));
                questions.add(new Question(
                        "What is the purpose of the `return` statement in C?",
                        Arrays.asList("Terminate the program", "Exit a function and return a value", "Restart the loop", "Allocate memory"),
                        1
                ));
                questions.add(new Question(
                        "Which header file is required for using the `printf` function?",
                        Arrays.asList("stdlib.h", "string.h", "stdio.h", "math.h"),
                        2
                ));
                questions.add(new Question(
                        "Which data type is used to store decimal numbers in C?",
                        Arrays.asList("int", "float", "char", "bool"),
                        1
                ));
                questions.add(new Question(
                        "What will be the output of the following code?\n\nint a = 10;\nint b = 20;\na = a + b;\nb = a - b;\na = a - b;\nprintf(\"%d %d\", a, b);",
                        Arrays.asList("10 20", "20 10", "30 30", "Compiler Error"),
                        1
                ));
                questions.add(new Question(
                        "Which of the following loops ensures the code inside it is executed at least once?",
                        Arrays.asList("for", "while", "do-while", "None of the above"),
                        2
                ));
                questions.add(new Question(
                        "What is the default value of an uninitialized variable in C?",
                        Arrays.asList("0", "Garbage Value", "NULL", "Depends on the compiler"),
                        1
                ));
                questions.add(new Question(
                        "Which operator is used to access the value of a pointer variable in C?",
                        Arrays.asList("&", "*", "->", "."),
                        1
                ));
                break;

            case 3: // Html
                questions.add(new Question(
                        "Which HTML tag is used to define a hyperlink?",
                        Arrays.asList("<a>", "<link>", "<href>", "<hyperlink>"),
                        0
                ));
                questions.add(new Question(
                        "What does the `<title>` tag in an HTML document do?",
                        Arrays.asList("Defines the title of the webpage displayed in the browser's title bar or tab",
                                "Sets the heading of the page",
                                "Adds a tooltip to elements",
                                "Defines the main content of the page"),
                        0
                ));
                questions.add(new Question(
                        "Which attribute is used to provide an alternative text for an image in HTML?",
                        Arrays.asList("src", "alt", "title", "href"),
                        1
                ));
                questions.add(new Question(
                        "What is the correct syntax for creating an ordered list in HTML?",
                        Arrays.asList("<ul>", "<ol>", "<list>", "<ordered>"),
                        1
                ));
                questions.add(new Question(
                        "Which tag is used to insert a line break in HTML?",
                        Arrays.asList("<break>", "<br>", "<lb>", "<line>"),
                        1
                ));
                questions.add(new Question(
                        "What is the purpose of the `<meta>` tag in an HTML document?",
                        Arrays.asList("To add metadata like keywords, author, and description",
                                "To define the style of the page",
                                "To insert an image",
                                "To create a footer"),
                        0
                ));
                questions.add(new Question(
                        "Which attribute is used to specify the URL of a linked page in the `<a>` tag?",
                        Arrays.asList("src", "href", "link", "url"),
                        1
                ));
                questions.add(new Question(
                        "Which tag is used to define a table header in HTML?",
                        Arrays.asList("<th>", "<thead>", "<tr>", "<td>"),
                        0
                ));
                questions.add(new Question(
                        "What is the correct way to specify a background color in HTML?",
                        Arrays.asList("background:color", "style=\"background-color:\"", "bgcolor=", "background-style:color"),
                        1
                ));
                questions.add(new Question(
                        "Which doctype declaration is correct for HTML5?",
                        Arrays.asList("<!DOCTYPE html>", "<!DOCTYPE HTML5>", "<html doctype=\"html\">", "<doctype html5>"),
                        0
                ));

                break;

            case 4: // DSA
                questions.add(new Question(
                        "Which data structure uses the Last In First Out (LIFO) principle?",
                        Arrays.asList("Queue", "Stack", "Array", "Linked List"),
                        1
                ));
                questions.add(new Question(
                        "What is the time complexity of searching for an element in a balanced binary search tree?",
                        Arrays.asList("O(n)", "O(log n)", "O(n log n)", "O(1)"),
                        1
                ));
                questions.add(new Question(
                        "Which sorting algorithm has the worst-case time complexity of O(n^2)?",
                        Arrays.asList("Merge Sort", "Quick Sort", "Bubble Sort", "Heap Sort"),
                        2
                ));
                questions.add(new Question(
                        "In a graph, what is the term for a path that starts and ends at the same vertex?",
                        Arrays.asList("Hamiltonian Path", "Eulerian Path", "Cycle", "Tree"),
                        2
                ));
                questions.add(new Question(
                        "Which data structure is used for implementing recursion?",
                        Arrays.asList("Queue", "Heap", "Stack", "Tree"),
                        2
                ));
                questions.add(new Question(
                        "What is the purpose of a hash function in hashing?",
                        Arrays.asList("To compress data", "To sort data", "To map keys to indices", "To allocate memory"),
                        2
                ));
                questions.add(new Question(
                        "Which of the following algorithms is used to find the shortest path in a graph?",
                        Arrays.asList("Kruskal's Algorithm", "Prim's Algorithm", "Dijkstra's Algorithm", "DFS"),
                        2
                ));
                questions.add(new Question(
                        "What is the time complexity of inserting an element at the beginning of a singly linked list?",
                        Arrays.asList("O(1)", "O(log n)", "O(n)", "O(n^2)"),
                        0
                ));
                questions.add(new Question(
                        "What is the maximum number of edges in a simple undirected graph with n vertices?",
                        Arrays.asList("n^2", "n*(n-1)/2", "n*(n+1)/2", "n^2 - n"),
                        1
                ));
                questions.add(new Question(
                        "Which traversal algorithm visits all the vertices of a graph in Breadth-First Search (BFS)?",
                        Arrays.asList("Inorder Traversal", "Preorder Traversal", "Level-Order Traversal", "Depth-First Traversal"),
                        2
                ));

                break;

            case 5: // React
                questions.add(new Question(
                        "What is the purpose of the `useState` hook in React?",
                        Arrays.asList("To manage state in a functional component",
                                "To manage side effects in a component",
                                "To create a new React component",
                                "To handle props in a component"),
                        0
                ));
                questions.add(new Question(
                        "What does JSX stand for in React?",
                        Arrays.asList("JavaScript XML",
                                "JavaScript Extension",
                                "JavaScript XCode",
                                "JavaScript Syntax"),
                        0
                ));
                questions.add(new Question(
                        "Which of the following is true about React components?",
                        Arrays.asList("Components can only be class-based",
                                "Components must always return JSX",
                                "Components can be either functional or class-based",
                                "Components are used only for styling"),
                        2
                ));
                questions.add(new Question(
                        "Which method is used to update state in a class component?",
                        Arrays.asList("setState()", "updateState()", "changeState()", "modifyState()"),
                        0
                ));
                questions.add(new Question(
                        "What is the default port for a React application running on `create-react-app`?",
                        Arrays.asList("3000", "8000", "8080", "5000"),
                        0
                ));
                questions.add(new Question(
                        "Which React hook is used to perform side effects in a functional component?",
                        Arrays.asList("useState", "useEffect", "useRef", "useContext"),
                        1
                ));
                questions.add(new Question(
                        "What is the purpose of React's `key` attribute?",
                        Arrays.asList("To apply CSS styles to elements",
                                "To uniquely identify elements in a list",
                                "To trigger component re-rendering",
                                "To manage state in components"),
                        1
                ));
                questions.add(new Question(
                        "Which of the following is true about props in React?",
                        Arrays.asList("Props are mutable",
                                "Props are used to pass data between components",
                                "Props are only available in class components",
                                "Props are used to manage state"),
                        1
                ));
                questions.add(new Question(
                        "What does React use to optimize rendering performance?",
                        Arrays.asList("Virtual DOM",
                                "Shadow DOM",
                                "Direct DOM",
                                "Event Delegation"),
                        0
                ));
                questions.add(new Question(
                        "How do you pass data from a parent component to a child component in React?",
                        Arrays.asList("Using state",
                                "Using props",
                                "Using Redux",
                                "Using Context API"),
                        1
                ));

                break;

            case 6: // Node
                questions.add(new Question(
                        "What is Node.js primarily used for?",
                        Arrays.asList("Client-side scripting",
                                "Server-side scripting",
                                "Database management",
                                "Mobile app development"),
                        1
                ));
                questions.add(new Question(
                        "Which module in Node.js is used to handle file system operations?",
                        Arrays.asList("fs", "http", "events", "path"),
                        0
                ));
                questions.add(new Question(
                        "What does `npm` stand for in Node.js?",
                        Arrays.asList("Node Package Manager",
                                "Node Programming Module",
                                "Network Package Manager",
                                "None of the above"),
                        0
                ));
                questions.add(new Question(
                        "Which method is used to create a server in Node.js?",
                        Arrays.asList("http.createServer()", "server.create()", "node.createServer()", "create.http()"),
                        0
                ));
                questions.add(new Question(
                        "Which of the following is true about Node.js?",
                        Arrays.asList("Node.js is a client-side framework",
                                "Node.js is a runtime environment for JavaScript",
                                "Node.js is used only for database management",
                                "Node.js does not support non-blocking operations"),
                        1
                ));
                questions.add(new Question(
                        "What is the purpose of the `package.json` file in a Node.js project?",
                        Arrays.asList("To define the entry point of the application",
                                "To list the project's dependencies and scripts",
                                "To configure the database connection",
                                "To store user-specific settings"),
                        1
                ));
                questions.add(new Question(
                        "Which module in Node.js is used to create and manage servers?",
                        Arrays.asList("http", "url", "fs", "os"),
                        0
                ));
                questions.add(new Question(
                        "What does the `require` function do in Node.js?",
                        Arrays.asList("Loads external modules",
                                "Creates an HTTP server",
                                "Reads environment variables",
                                "Handles errors in the code"),
                        0
                ));
                questions.add(new Question(
                        "Which Node.js module provides utilities for working with file and directory paths?",
                        Arrays.asList("url", "path", "fs", "querystring"),
                        1
                ));
                questions.add(new Question(
                        "What is the default behavior of Node.js when it encounters an unhandled exception?",
                        Arrays.asList("It logs the error and continues execution",
                                "It stops the execution of the program",
                                "It retries the failed operation",
                                "It ignores the error and proceeds"),
                        1
                ));

                break;

            case 7: // csharp
                questions.add(new Question(
                        "What is the primary purpose of the `using` keyword in C#?",
                        Arrays.asList("To include namespaces",
                                "To handle exceptions",
                                "To define variables",
                                "To execute loops"),
                        0
                ));
                questions.add(new Question(
                        "Which of the following is the base class for all C# classes?",
                        Arrays.asList("System.Object", "System.Base", "System.Class", "System.Root"),
                        0
                ));
                questions.add(new Question(
                        "What is the correct syntax to declare a nullable type in C#?",
                        Arrays.asList("int x = null;",
                                "int? x;",
                                "int x?;",
                                "nullable int x;"),
                        1
                ));
                questions.add(new Question(
                        "Which of the following is a value type in C#?",
                        Arrays.asList("String", "Array", "Enum", "Delegate"),
                        2
                ));
                questions.add(new Question(
                        "What is the purpose of the `async` and `await` keywords in C#?",
                        Arrays.asList("To write asynchronous code",
                                "To define a property",
                                "To create a loop",
                                "To handle exceptions"),
                        0
                ));
                questions.add(new Question(
                        "Which of the following is true about C# properties?",
                        Arrays.asList("Properties are used to execute methods",
                                "Properties are used to define fields",
                                "Properties are used to encapsulate fields with getter and setter methods",
                                "Properties are used for inheritance"),
                        2
                ));
                questions.add(new Question(
                        "What is the correct syntax for a conditional statement in C#?",
                        Arrays.asList("if condition do",
                                "if (condition) {}",
                                "if {condition}",
                                "if condition {}"),
                        1
                ));
                questions.add(new Question(
                        "Which method is used to read user input from the console in C#?",
                        Arrays.asList("Console.Read()", "Console.ReadLine()", "Console.Input()", "Console.GetInput()"),
                        1
                ));
                questions.add(new Question(
                        "What is the entry point of a C# application?",
                        Arrays.asList("Main()", "Start()", "Init()", "Entry()"),
                        0
                ));
                questions.add(new Question(
                        "What is the purpose of the `delegate` keyword in C#?",
                        Arrays.asList("To define a method signature for callbacks",
                                "To create a new class",
                                "To implement inheritance",
                                "To handle exceptions"),
                        0
                ));

                break;

            case 8: // SQL
                questions.add(new Question(
                        "What does SQL stand for?",
                        Arrays.asList("Structured Query Language",
                                "Sequential Query Language",
                                "System Query Language",
                                "Syntax Query Language"),
                        0
                ));
                questions.add(new Question(
                        "Which SQL statement is used to retrieve data from a database?",
                        Arrays.asList("GET", "SELECT", "FETCH", "RETRIEVE"),
                        1
                ));
                questions.add(new Question(
                        "Which clause is used to filter records in a SQL query?",
                        Arrays.asList("WHERE", "FILTER", "ORDER BY", "GROUP BY"),
                        0
                ));
                questions.add(new Question(
                        "Which SQL keyword is used to sort the result set?",
                        Arrays.asList("SORT", "ORDER BY", "GROUP BY", "ARRANGE"),
                        1
                ));
                questions.add(new Question(
                        "What is a primary key in SQL?",
                        Arrays.asList("A unique identifier for a table record",
                                "A foreign key in another table",
                                "A column with duplicate values",
                                "A reserved SQL keyword"),
                        0
                ));
                questions.add(new Question(
                        "Which SQL function is used to count the number of rows in a table?",
                        Arrays.asList("SUM()", "COUNT()", "TOTAL()", "ROWCOUNT()"),
                        1
                ));
                questions.add(new Question(
                        "Which SQL statement is used to update data in a table?",
                        Arrays.asList("UPDATE", "MODIFY", "CHANGE", "ALTER"),
                        0
                ));
                questions.add(new Question(
                        "What is the purpose of the `JOIN` clause in SQL?",
                        Arrays.asList("To combine rows from two or more tables",
                                "To create a new table",
                                "To delete rows in a table",
                                "To filter data in a table"),
                        0
                ));
                questions.add(new Question(
                        "What is the difference between `INNER JOIN` and `LEFT JOIN`?",
                        Arrays.asList("`INNER JOIN` returns all rows, `LEFT JOIN` returns only matching rows",
                                "`INNER JOIN` returns only matching rows, `LEFT JOIN` returns all rows from the left table",
                                "`INNER JOIN` is used for sorting, `LEFT JOIN` is used for filtering",
                                "There is no difference"),
                        1
                ));
                questions.add(new Question(
                        "Which SQL command is used to delete a table from a database?",
                        Arrays.asList("DELETE", "REMOVE", "DROP", "TRUNCATE"),
                        2
                ));

                break;
        }

        return questions;
    }
}