package com.example.quizapp.models;

public class Category {
    private int id;
    private String name;
    private int imageResource;
    private String backgroundColor;

    public Category(int id, String name, int imageResource, String backgroundColor) {
        this.id = id;
        this.name = name;
        this.imageResource = imageResource;
        this.backgroundColor = backgroundColor;
    }

    // Getters and setters
    public int getId() { return id; }
    public String getName() { return name; }
    public int getImageResource() { return imageResource; }
    public String getBackgroundColor() { return backgroundColor; }
}
