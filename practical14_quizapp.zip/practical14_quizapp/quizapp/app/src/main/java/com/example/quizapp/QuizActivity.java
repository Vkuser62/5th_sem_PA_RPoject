package com.example.quizapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.quizapp.models.Question;
import com.example.quizapp.utils.QuizData;

import java.util.List;

public class QuizActivity extends AppCompatActivity {
    private TextView questionText;
    private Button[] optionButtons;
    private TextView progressText;

    private List<Question> questions;
    private int currentQuestionIndex = 0;
    private int score = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_quiz);
        int categoryId = getIntent().getIntExtra("CATEGORY_ID", 1);
        questions = QuizData.getQuestionsForCategory(categoryId);

        initializeViews();
        displayQuestion();
    }
    private void initializeViews() {
        questionText = findViewById(R.id.questionText);
        progressText = findViewById(R.id.progressText);

        optionButtons = new Button[]{
                findViewById(R.id.option1),
                findViewById(R.id.option2),
                findViewById(R.id.option3),
                findViewById(R.id.option4)
        };

        for (int i = 0; i < optionButtons.length; i++) {
            final int optionIndex = i;
            optionButtons[i].setOnClickListener(v -> checkAnswer(optionIndex));
        }
    }

    private void displayQuestion() {
        Question currentQuestion = questions.get(currentQuestionIndex);
        questionText.setText(currentQuestion.getQuestionText());

        List<String> options = currentQuestion.getOptions();
        for (int i = 0; i < options.size(); i++) {
            optionButtons[i].setText(options.get(i));
            optionButtons[i].setEnabled(true);
        }

        progressText.setText(String.format("Question %d/%d",
                currentQuestionIndex + 1, questions.size()));
    }

    private void checkAnswer(int selectedOption) {
        Question currentQuestion = questions.get(currentQuestionIndex);

        if (selectedOption == currentQuestion.getCorrectAnswerIndex()) {
            score++;
        }

        for (Button button : optionButtons) {
            button.setEnabled(false);
        }

        currentQuestionIndex++;

        if (currentQuestionIndex < questions.size()) {
            findViewById(R.id.nextButton).setVisibility(View.VISIBLE);
        } else {
            showResult();
        }
    }

    private void showResult() {
        Intent intent = new Intent(this, ResultActivity.class);
        intent.putExtra("SCORE", score);
        intent.putExtra("TOTAL_QUESTIONS", questions.size());
        startActivity(intent);
        finish();
    }

    public void onNextClick(View view) {
        displayQuestion();
        view.setVisibility(View.GONE);
    }
}